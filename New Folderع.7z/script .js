let cart = [];

function addToCart(productName, price) {
    cart.push({ name: productName, price: price, quantity: 1 });
    alert(`${productName} به سبد خرید اضافه شد!`);
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    if (cartItems && cartTotal) {
        cartItems.innerHTML = '';
        let total = 0;
        cart.forEach(item => {
            total += item.price * item.quantity;
            cartItems.innerHTML += `<div>${item.name} - ${item.quantity} عدد - ${item.price * item.quantity} تومان</div>`;
        });
        cartTotal.textContent = `${total} تومان`;
    }
}

function proceedToPayment() {
    alert('انتقال به درگاه پرداخت... (نیاز به درگاه واقعی دارد)');
}